import {connect} from 'react-redux';
import Counter from '../Components/Counter';
import { Increment, Decrement } from '../Components/Actions/CounterActions';

var mapStateToProps=(state)=> {
    return {
        countVal:state.count
    }
}

var mapDispatchToProps=(dispatch)=>{
    return {
        onIncrement:()=>{
            dispatch(Increment());
        },
        onDecrement:()=>{
            dispatch(Decrement());
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Counter);