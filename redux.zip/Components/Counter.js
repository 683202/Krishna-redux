import React, {Component} from 'react';

class Counter extends Component {
    render() {
        return(
            <React.Fragment>
                <h1>{this.props.countVal}</h1>
                <button onClick={()=>{
                    this.props.onIncrement();
                }}>Increment</button>
                <button onClick={()=>{
                    this.props.onDecrement();
                }}>Decrement</button>
            </React.Fragment>
        );
    }
}



export default Counter;