function Increment() {
    console.log('Inside increment function in counterActions.js');
    return {
        type:"INCREMENT"
    }
}

function Decrement() {
    return {
        type: "DECREMENT"
    }
}

export {Increment, Decrement};